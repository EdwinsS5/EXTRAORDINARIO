﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace GYMEXTRAOR
{
    public partial class FormReservas : Form
    {
        private static string connectionString = "Server=DESKTOP-P5L5BPG\\SQLEXPRESS01;Database=GYM;Integrated Security=True;TrustServerCertificate=True;";

        public FormReservas()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Reservas (ID_Miembro, ID_Clase, FechaReserva) VALUES (@IDMiembro, @IDClase, @FechaReserva)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@IDMiembro", int.Parse(txtIDMiembro.Text));
                    command.Parameters.AddWithValue("@IDClase", int.Parse(txtIDClase.Text));
                    command.Parameters.AddWithValue("@FechaReserva", dtpFechaReserva.Value);

                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Reserva agregada exitosamente.");
                        ListarReservas();
                        LimpiarCampos();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            ListarReservas();
        }

        private void ListarReservas()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT ID_Reserva, ID_Miembro, ID_Clase, FechaReserva FROM Reservas";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgvReservas.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Reservas SET ID_Miembro = @IDMiembro, ID_Clase = @IDClase, FechaReserva = @FechaReserva WHERE ID_Reserva = @IDReserva";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@IDReserva", int.Parse(txtIDReserva.Text));
                    command.Parameters.AddWithValue("@IDMiembro", int.Parse(txtIDMiembro.Text));
                    command.Parameters.AddWithValue("@IDClase", int.Parse(txtIDClase.Text));
                    command.Parameters.AddWithValue("@FechaReserva", dtpFechaReserva.Value);

                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Reserva actualizada exitosamente.");
                        ListarReservas();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró la reserva con el ID ingresado.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Reservas WHERE ID_Reserva = @IDReserva";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@IDReserva", int.Parse(txtIDReserva.Text));

                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Reserva eliminada exitosamente.");
                        ListarReservas();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró la reserva con el ID ingresado.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void LimpiarCampos()
        {
            txtIDReserva.Clear();
            txtIDMiembro.Clear();
            txtIDClase.Clear();
            dtpFechaReserva.Value = DateTime.Now;
        }
    }
}