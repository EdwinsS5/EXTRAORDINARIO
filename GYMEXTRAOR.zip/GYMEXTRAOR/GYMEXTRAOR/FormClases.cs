﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace GYMEXTRAOR
{
    public partial class FormClases: Form
    {
        private static string connectionString = "Server=DESKTOP-P5L5BPG\\SQLEXPRESS01;Database=GYM;Integrated Security=True;TrustServerCertificate=True;";

        public FormClases()
        {
            InitializeComponent();
        }

        private void btnAgregarClase_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Clases (NombreClase, Horario, CapacidadMaxima) VALUES (@NombreClase, @Horario, @CapacidadMaxima)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@NombreClase", txtNombreClase.Text);
                    command.Parameters.AddWithValue("@Horario", dtpHorario.Value.TimeOfDay);
                    command.Parameters.AddWithValue("@CapacidadMaxima", int.Parse(txtCapacidadMaxima.Text));

                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Clase agregada exitosamente.");
                        ListarClases();
                        LimpiarCampos();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void btnListarClases_Click(object sender, EventArgs e)
        {
            ListarClases();
        }

        private void ListarClases()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT ID_Clase, NombreClase, Horario, CapacidadMaxima FROM Clases";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgvClases.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void btnActualizarClase_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Clases SET NombreClase = @NombreClase, Horario = @Horario, CapacidadMaxima = @CapacidadMaxima WHERE ID_Clase = @ID_Clase";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Clase", int.Parse(txtID.Text));
                    command.Parameters.AddWithValue("@NombreClase", txtNombreClase.Text);
                    command.Parameters.AddWithValue("@Horario", dtpHorario.Value.TimeOfDay);
                    command.Parameters.AddWithValue("@CapacidadMaxima", int.Parse(txtCapacidadMaxima.Text));

                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Clase actualizada exitosamente.");
                        ListarClases();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró la clase con el ID ingresado.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void btnEliminarClase_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Clases WHERE ID_Clase = @ID_Clase";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Clase", int.Parse(txtID.Text));

                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Clase eliminada exitosamente.");
                        ListarClases();
                        LimpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró la clase con el ID ingresado.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void LimpiarCampos()
        {
            txtID.Clear();
            txtNombreClase.Clear();
            txtCapacidadMaxima.Clear();
            dtpHorario.Value = DateTime.Now; // Restablece el horario al actual
        }
    }
}