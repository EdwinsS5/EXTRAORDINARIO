﻿namespace GYMEXTRAOR
{
    partial class FormClases
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvClases;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtNombreClase;
        private System.Windows.Forms.TextBox txtCapacidadMaxima;
        private System.Windows.Forms.DateTimePicker dtpHorario;
        private System.Windows.Forms.Button btnAgregarClase;
        private System.Windows.Forms.Button btnListarClases;
        private System.Windows.Forms.Button btnActualizarClase;
        private System.Windows.Forms.Button btnEliminarClase;
        private System.Windows.Forms.Button btnLimpiar;

        /// <summary>
        /// Limpiar los recursos que se están utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados deben ser eliminados; de lo contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Método necesario para admitir el Diseñador de Windows Forms.
        /// No se puede modificar el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvClases = new System.Windows.Forms.DataGridView();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtNombreClase = new System.Windows.Forms.TextBox();
            this.txtCapacidadMaxima = new System.Windows.Forms.TextBox();
            this.dtpHorario = new System.Windows.Forms.DateTimePicker();
            this.btnAgregarClase = new System.Windows.Forms.Button();
            this.btnListarClases = new System.Windows.Forms.Button();
            this.btnActualizarClase = new System.Windows.Forms.Button();
            this.btnEliminarClase = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClases)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvClases
            // 
            this.dgvClases.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvClases.Location = new System.Drawing.Point(12, 200);
            this.dgvClases.Name = "dgvClases";
            this.dgvClases.RowHeadersWidth = 51;
            this.dgvClases.Size = new System.Drawing.Size(600, 200);
            this.dgvClases.TabIndex = 0;
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(12, 12);
            this.txtID.Name = "txtID";
            this.txtID.PlaceholderText = "ID Clase";
            this.txtID.Size = new System.Drawing.Size(100, 27);
            this.txtID.TabIndex = 1;
            // 
            // txtNombreClase
            // 
            this.txtNombreClase.Location = new System.Drawing.Point(12, 45);
            this.txtNombreClase.Name = "txtNombreClase";
            this.txtNombreClase.PlaceholderText = "Nombre de la Clase";
            this.txtNombreClase.Size = new System.Drawing.Size(200, 27);
            this.txtNombreClase.TabIndex = 2;
            // 
            // txtCapacidadMaxima
            // 
            this.txtCapacidadMaxima.Location = new System.Drawing.Point(12, 78);
            this.txtCapacidadMaxima.Name = "txtCapacidadMaxima";
            this.txtCapacidadMaxima.PlaceholderText = "Capacidad Máxima";
            this.txtCapacidadMaxima.Size = new System.Drawing.Size(200, 27);
            this.txtCapacidadMaxima.TabIndex = 3;
            // 
            // dtpHorario
            // 
            this.dtpHorario.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpHorario.Location = new System.Drawing.Point(12, 111);
            this.dtpHorario.Name = "dtpHorario";
            this.dtpHorario.Size = new System.Drawing.Size(200, 27);
            this.dtpHorario.TabIndex = 4;
            // 
            // btnAgregarClase
            // 
            this.btnAgregarClase.Location = new System.Drawing.Point(250, 12);
            this.btnAgregarClase.Name = "btnAgregarClase";
            this.btnAgregarClase.Size = new System.Drawing.Size(100, 27);
            this.btnAgregarClase.TabIndex = 5;
            this.btnAgregarClase.Text = "Agregar";
            this.btnAgregarClase.UseVisualStyleBackColor = true;
            this.btnAgregarClase.Click += new System.EventHandler(this.btnAgregarClase_Click);
            // 
            // btnListarClases
            // 
            this.btnListarClases.Location = new System.Drawing.Point(250, 45);
            this.btnListarClases.Name = "btnListarClases";
            this.btnListarClases.Size = new System.Drawing.Size(100, 27);
            this.btnListarClases.TabIndex = 6;
            this.btnListarClases.Text = "Listar";
            this.btnListarClases.UseVisualStyleBackColor = true;
            this.btnListarClases.Click += new System.EventHandler(this.btnListarClases_Click);
            // 
            // btnActualizarClase
            // 
            this.btnActualizarClase.Location = new System.Drawing.Point(250, 78);
            this.btnActualizarClase.Name = "btnActualizarClase";
            this.btnActualizarClase.Size = new System.Drawing.Size(100, 27);
            this.btnActualizarClase.TabIndex = 7;
            this.btnActualizarClase.Text = "Actualizar";
            this.btnActualizarClase.UseVisualStyleBackColor = true;
            this.btnActualizarClase.Click += new System.EventHandler(this.btnActualizarClase_Click);
            // 
            // btnEliminarClase
            // 
            this.btnEliminarClase.Location = new System.Drawing.Point(250, 111);
            this.btnEliminarClase.Name = "btnEliminarClase";
            this.btnEliminarClase.Size = new System.Drawing.Size(100, 27);
            this.btnEliminarClase.TabIndex = 8;
            this.btnEliminarClase.Text = "Eliminar";
            this.btnEliminarClase.UseVisualStyleBackColor = true;
            this.btnEliminarClase.Click += new System.EventHandler(this.btnEliminarClase_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(250, 144);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(100, 27);
            this.btnLimpiar.TabIndex = 9;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // ClasesForm
            // 
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnEliminarClase);
            this.Controls.Add(this.btnActualizarClase);
            this.Controls.Add(this.btnListarClases);
            this.Controls.Add(this.btnAgregarClase);
            this.Controls.Add(this.dtpHorario);
            this.Controls.Add(this.txtCapacidadMaxima);
            this.Controls.Add(this.txtNombreClase);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.dgvClases);
            this.Name = "ClasesForm";
            this.Text = "Gestión de Clases";
            ((System.ComponentModel.ISupportInitialize)(this.dgvClases)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}