﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace GYMEXTRAOR
{
    public partial class FormMembresias : Form
    {
        private static string connectionString = "Server=DESKTOP-P5L5BPG\\SQLEXPRESS01;Database=GYM;Integrated Security=True;TrustServerCertificate=True;";

        public FormMembresias()
        {
            InitializeComponent();
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            // Implementación del método para listar membresías
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT ID_Membresia, TipoMembresia, Precio, FechaInicio, FechaFin FROM Membresias";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgvMembresias.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al listar membresías: {ex.Message}");
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Implementación del método para agregar membresías
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Membresias (TipoMembresia, Precio, FechaInicio, FechaFin) VALUES (@TipoMembresia, @Precio, @FechaInicio, @FechaFin)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@TipoMembresia", txtTipoMembresia.Text);
                    command.Parameters.AddWithValue("@Precio", Convert.ToDecimal(txtPrecio.Text));
                    command.Parameters.AddWithValue("@FechaInicio", dtpFechaInicio.Value);
                    command.Parameters.AddWithValue("@FechaFin", dtpFechaFin.Value);

                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Membresía agregada exitosamente.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al agregar membresía: {ex.Message}");
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            // Implementación del método para actualizar membresías
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Membresias SET TipoMembresia = @TipoMembresia, Precio = @Precio, FechaInicio = @FechaInicio, FechaFin = @FechaFin WHERE ID_Membresia = @ID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID", Convert.ToInt32(txtID.Text));
                    command.Parameters.AddWithValue("@TipoMembresia", txtTipoMembresia.Text);
                    command.Parameters.AddWithValue("@Precio", Convert.ToDecimal(txtPrecio.Text));
                    command.Parameters.AddWithValue("@FechaInicio", dtpFechaInicio.Value);
                    command.Parameters.AddWithValue("@FechaFin", dtpFechaFin.Value);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Membresía actualizada exitosamente.");
                    }
                    else
                    {
                        MessageBox.Show("No se encontró la membresía con el ID proporcionado.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al actualizar membresía: {ex.Message}");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            // Implementación del método para eliminar una membresía
            try
            {
                using (SqlConnection connection = new SqlConnection("Server=DESKTOP-P5L5BPG\\SQLEXPRESS01;Database=GYM;Integrated Security=True;TrustServerCertificate=True;"))
                {
                    string query = "DELETE FROM Membresias WHERE ID_Membresia = @ID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID", Convert.ToInt32(txtID.Text));

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Membresía eliminada exitosamente.");
                    }
                    else
                    {
                        MessageBox.Show("No se encontró la membresía con el ID proporcionado.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar membresía: {ex.Message}");
            }
        }
    }
}