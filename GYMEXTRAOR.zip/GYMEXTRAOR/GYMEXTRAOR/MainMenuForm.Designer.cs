﻿namespace GYMEXTRAOR
{
    partial class MainMenuForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnGestionarMiembros;
        private System.Windows.Forms.Button btnGestionarMembresias;
        private System.Windows.Forms.Button btnGestionarClases;
        private System.Windows.Forms.Button btnGestionarInstructores;
        private System.Windows.Forms.Button btnGestionarReservas;
        private System.Windows.Forms.Button btnSalir;

        /// <summary>
        /// Limpiar los recursos utilizados.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados deben ser liberados; False de lo contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Método necesario para admitir el Diseñador de Windows Forms.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGestionarMiembros = new System.Windows.Forms.Button();
            this.btnGestionarMembresias = new System.Windows.Forms.Button();
            this.btnGestionarClases = new System.Windows.Forms.Button();
            this.btnGestionarInstructores = new System.Windows.Forms.Button();
            this.btnGestionarReservas = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGestionarMiembros
            // 
            this.btnGestionarMiembros.Location = new System.Drawing.Point(50, 30);
            this.btnGestionarMiembros.Name = "btnGestionarMiembros";
            this.btnGestionarMiembros.Size = new System.Drawing.Size(200, 40);
            this.btnGestionarMiembros.TabIndex = 0;
            this.btnGestionarMiembros.Text = "Gestionar Miembros";
            this.btnGestionarMiembros.UseVisualStyleBackColor = true;
            this.btnGestionarMiembros.Click += new System.EventHandler(this.btnGestionarMiembros_Click);
            // 
            // btnGestionarMembresias
            // 
            this.btnGestionarMembresias.Location = new System.Drawing.Point(50, 80);
            this.btnGestionarMembresias.Name = "btnGestionarMembresias";
            this.btnGestionarMembresias.Size = new System.Drawing.Size(200, 40);
            this.btnGestionarMembresias.TabIndex = 1;
            this.btnGestionarMembresias.Text = "Gestionar Membresías";
            this.btnGestionarMembresias.UseVisualStyleBackColor = true;
            this.btnGestionarMembresias.Click += new System.EventHandler(this.btnGestionarMembresias_Click);
            //// 
            ///btnGestionarClases
            ///
            this.btnGestionarClases.Location = new System.Drawing.Point(50, 130);
            this.btnGestionarClases.Name = "btnGestionarClases";
            this.btnGestionarClases.Size = new System.Drawing.Size(200, 40);
            this.btnGestionarClases.TabIndex = 2;
            this.btnGestionarClases.Text = "Gestionar Clases";
            this.btnGestionarClases.UseVisualStyleBackColor = true;
            this.btnGestionarClases.Click += new System.EventHandler(this.btnGestionarClases_Click);
            //// 
            //// btnGestionarInstructores
            //// 
            this.btnGestionarInstructores.Location = new System.Drawing.Point(50, 180);
            this.btnGestionarInstructores.Name = "btnGestionarInstructores";
            this.btnGestionarInstructores.Size = new System.Drawing.Size(200, 40);
            this.btnGestionarInstructores.TabIndex = 3;
            this.btnGestionarInstructores.Text = "Gestionar Instructores";
            this.btnGestionarInstructores.UseVisualStyleBackColor = true;
            this.btnGestionarInstructores.Click += new System.EventHandler(this.btnGestionarInstructores_Click);
            //// 
            //// btnGestionarReservas
            //// 
            this.btnGestionarReservas.Location = new System.Drawing.Point(50, 230);
            this.btnGestionarReservas.Name = "btnGestionarReservas";
            this.btnGestionarReservas.Size = new System.Drawing.Size(200, 40);
            this.btnGestionarReservas.TabIndex = 4;
            this.btnGestionarReservas.Text = "Gestionar Reservas";
            this.btnGestionarReservas.UseVisualStyleBackColor = true;
            this.btnGestionarReservas.Click += new System.EventHandler(this.btnGestionarReservas_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(50, 280);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(200, 40);
            this.btnSalir.TabIndex = 5;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // MainMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 350);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnGestionarReservas);
            this.Controls.Add(this.btnGestionarInstructores);
            this.Controls.Add(this.btnGestionarClases);
            this.Controls.Add(this.btnGestionarMembresias);
            this.Controls.Add(this.btnGestionarMiembros);
            this.Name = "MainMenuForm";
            this.Text = "Menú Principal";
            this.ResumeLayout(false);

        }
    }
}