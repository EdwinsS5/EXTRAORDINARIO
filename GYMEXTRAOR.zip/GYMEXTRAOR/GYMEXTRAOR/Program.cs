using System;
using System.Windows.Forms;

namespace GYMEXTRAOR
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicaci�n.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Configuraci�n inicial de la aplicaci�n
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Mostrar un mensaje de depuraci�n
            Console.WriteLine("Inicio del programa"); // Depuraci�n

            // Crear y mostrar el formulario principal
            Application.Run(new MainMenuForm());
        }
    }
}