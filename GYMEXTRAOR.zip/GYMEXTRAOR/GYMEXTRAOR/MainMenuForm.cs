﻿using System;
using System.Windows.Forms;

namespace GYMEXTRAOR
{
    public partial class MainMenuForm : Form
    {
        public MainMenuForm()
        {
            InitializeComponent();
        }

        private void btnGestionarMiembros_Click(object sender, EventArgs e)
        {
            // Abrir el formulario de gestión de miembros
            FormMiembros formMiembros = new FormMiembros();
            formMiembros.ShowDialog();
        }

        private void btnGestionarMembresias_Click(object sender, EventArgs e)
        {
            // Abrir el formulario de gestión de membresías
            FormMembresias formMembresias = new FormMembresias();
            formMembresias.ShowDialog();
        }

        private void btnGestionarClases_Click(object sender, EventArgs e)
        {
            // Abrir el formulario de gestión de clases
            FormClases formClases = new FormClases();
            formClases.ShowDialog();
        }

        private void btnGestionarInstructores_Click(object sender, EventArgs e)
        {
            // Abrir el formulario de gestión de instructores
            FormInstructores formInstructores = new FormInstructores();
            formInstructores.ShowDialog();
        }

        private void btnGestionarReservas_Click(object sender, EventArgs e)
        {
            // Abrir el formulario de gestión de reservas
            FormReservas formReservas = new FormReservas();
            formReservas.ShowDialog();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
             //Cerrar la aplicación
            Application.Exit();
        }
    }
}