﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace GYMEXTRAOR.CLASES
{
    internal class InstructoresCRUD
    {
        private static string connectionString = "Server=DESKTOP-P5L5BPG\\SQLEXPRESS01;Database=GYM;Integrated Security=True;TrustServerCertificate=True;";

        public static void Menu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("==============================================");
                Console.WriteLine("          Gestión de Instructores");
                Console.WriteLine("==============================================");
                Console.WriteLine("Seleccione una opción:");
                Console.WriteLine("1. Agregar Instructor");
                Console.WriteLine("2. Listar Instructores");
                Console.WriteLine("3. Actualizar Instructor");
                Console.WriteLine("4. Eliminar Instructor");
                Console.WriteLine("0. Volver al Menú Principal");

                Console.Write("Opción: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        AgregarInstructor();
                        break;
                    case "2":
                        ListarInstructores();
                        break;
                    case "3":
                        ActualizarInstructor();
                        break;
                    case "4":
                        EliminarInstructor();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Opción no válida.");
                        break;
                }

                Console.WriteLine("\nPresiona cualquier tecla para continuar...");
                Console.ReadKey();
            }
        }

        private static void AgregarInstructor()
        {
            Console.WriteLine("\nIngrese el nombre del instructor:");
            string nombre = Console.ReadLine();
            Console.WriteLine("Ingrese el apellido del instructor:");
            string apellido = Console.ReadLine();
            Console.WriteLine("Ingrese la especialidad del instructor:");
            string especialidad = Console.ReadLine();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Instructores (Nombre, Apellido, Especialidad) VALUES (@Nombre, @Apellido, @Especialidad)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nombre", nombre);
                command.Parameters.AddWithValue("@Apellido", apellido);
                command.Parameters.AddWithValue("@Especialidad", especialidad);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        Console.WriteLine("\nInstructor agregado exitosamente.");
                    else
                        Console.WriteLine("\nError al agregar el instructor.");
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Error de SQL: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error general: {ex.Message}");
                }
            }
        }

        private static void ListarInstructores()
        {
            Console.WriteLine("\nLista de Instructores:");
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Ajustamos la consulta SQL para reflejar las columnas reales de la tabla
                string query = "SELECT ID_Instructor, Nombre, Apellido, Especialidad FROM Instructores";
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"ID: {reader["ID_Instructor"]}, Nombre: {reader["Nombre"]} {reader["Apellido"]}, Especialidad: {reader["Especialidad"]}");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No hay instructores registrados.");
                    }

                    reader.Close();
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Error de SQL: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error general: {ex.Message}");
                }
            }
        }

        private static void ActualizarInstructor()
        {
            Console.WriteLine("\nIngrese el ID del instructor a actualizar:");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("Ingrese el nuevo nombre:");
                string nuevoNombre = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(nuevoNombre))
                {
                    Console.WriteLine("El nombre no puede estar vacío. Por favor, ingrese un nombre válido:");
                    nuevoNombre = Console.ReadLine();
                }

                Console.WriteLine("Ingrese el nuevo apellido:");
                string nuevoApellido = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(nuevoApellido))
                {
                    Console.WriteLine("El apellido no puede estar vacío. Por favor, ingrese un apellido válido:");
                    nuevoApellido = Console.ReadLine();
                }

                Console.WriteLine("Ingrese la nueva especialidad:");
                string nuevaEspecialidad = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(nuevaEspecialidad))
                {
                    Console.WriteLine("La especialidad no puede estar vacía. Por favor, ingrese una especialidad válida:");
                    nuevaEspecialidad = Console.ReadLine();
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Ajusta la consulta SQL para reflejar las columnas reales de la tabla
                    string query = "UPDATE Instructores SET Nombre = @Nombre, Apellido = @Apellido, Especialidad = @Especialidad WHERE ID_Instructor = @Id";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Id", id);
                    command.Parameters.AddWithValue("@Nombre", nuevoNombre);
                    command.Parameters.AddWithValue("@Apellido", nuevoApellido);
                    command.Parameters.AddWithValue("@Especialidad", nuevaEspecialidad);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                            Console.WriteLine("\nInstructor actualizado exitosamente.");
                        else
                            Console.WriteLine("\nInstructor no encontrado.");
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"Error de SQL: {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error general: {ex.Message}");
                    }
                }
            }
            else
            {
                Console.WriteLine("\nID inválido.");
            }
        }

        private static void EliminarInstructor()
        {
            Console.WriteLine("\nIngrese el ID del instructor a eliminar:");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Cambiamos 'Id' a 'ID_Instructor' para que coincida con la columna en la tabla
                    string query = "DELETE FROM Instructores WHERE ID_Instructor = @Id";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Id", id);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                            Console.WriteLine("\nInstructor eliminado exitosamente.");
                        else
                            Console.WriteLine("\nInstructor no encontrado.");
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"Error de SQL: {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error general: {ex.Message}");
                    }
                }
            }
            else
            {
                Console.WriteLine("\nID inválido.");
            }
        }
    }
}
