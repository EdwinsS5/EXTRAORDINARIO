﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace GYMEXTRAOR.CLASES
{
    internal class MiembrosCRUD
    {

        private static string connectionString = "Server=DESKTOP-P5L5BPG\\SQLEXPRESS01;Database=GYM;Integrated Security=True; TrustServerCertificate=True; ";

        public static void Menu()
        {
            while (true)
            {
                Console.Clear(); // Limpia la consola antes de mostrar el menú
                Console.WriteLine("Gestión de Miembros:");
                Console.WriteLine("1. Crear Miembro");
                Console.WriteLine("2. Leer Miembros");
                Console.WriteLine("3. Actualizar Miembro");
                Console.WriteLine("4. Eliminar Miembro");
                Console.WriteLine("0. Volver al Menú Principal");

                Console.Write("Seleccione una opción: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        CrearMiembro();
                        break;
                    case "2":
                        LeerMiembros();
                        break;
                    case "3":
                        ActualizarMiembro();
                        break;
                    case "4":
                        EliminarMiembro();
                        break;
                    case "0":
                        Console.WriteLine("Volviendo al menú principal...");
                        return; // Salir del método y regresar al menú principal (si existe)
                    default:
                        Console.WriteLine("Opción no válida.");
                        break;
                }

                // Esperar entrada del usuario antes de regresar al menú
                Console.WriteLine("\nPresiona cualquier tecla para regresar al menú...");
                Console.ReadKey();
            }
        }

        public static void CrearMiembro()
        {
            Console.Clear();
            Console.WriteLine("== Crear Miembro ==");

            Console.WriteLine("Ingrese el nombre del miembro:");
            string nombre = Console.ReadLine();
            while (string.IsNullOrWhiteSpace(nombre))
            {
                Console.WriteLine("El nombre no puede estar vacío. Por favor, ingrese un nombre válido:");
                nombre = Console.ReadLine();
            }

            Console.WriteLine("Ingrese el apellido del miembro:");
            string apellido = Console.ReadLine();
            while (string.IsNullOrWhiteSpace(apellido))
            {
                Console.WriteLine("El apellido no puede estar vacío. Por favor, ingrese un apellido válido:");
                apellido = Console.ReadLine();
            }

            Console.WriteLine("Ingrese la fecha de nacimiento (YYYY-MM-DD):");
            string fechaNacimientoInput = Console.ReadLine();
            DateTime fechaNacimiento;
            while (!DateTime.TryParse(fechaNacimientoInput, out fechaNacimiento))
            {
                Console.WriteLine("La fecha de nacimiento debe estar en el formato YYYY-MM-DD. Por favor, ingrese una fecha válida:");
                fechaNacimientoInput = Console.ReadLine();
            }

            Console.WriteLine("Ingrese el email:");
            string email = Console.ReadLine();
            while (string.IsNullOrWhiteSpace(email))
            {
                Console.WriteLine("El email no puede estar vacío. Por favor, ingrese un email válido:");
                email = Console.ReadLine();
            }

            Console.WriteLine("Ingrese el teléfono:");
            string telefono = Console.ReadLine();
            while (string.IsNullOrWhiteSpace(telefono))
            {
                Console.WriteLine("El teléfono no puede estar vacío. Por favor, ingrese un teléfono válido:");
                telefono = Console.ReadLine();
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Miembros (Nombre, Apellido, FechaNacimiento, Email, Telefono) VALUES (@Nombre, @Apellido, @FechaNacimiento, @Email, @Telefono)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nombre", nombre);
                command.Parameters.AddWithValue("@Apellido", apellido);
                command.Parameters.AddWithValue("@FechaNacimiento", fechaNacimiento);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@Telefono", telefono);

                try
                {
                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        Console.WriteLine("Miembro creado exitosamente.");
                    }
                    else
                    {
                        Console.WriteLine("No se pudo crear el miembro.");
                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Error de SQL: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error general: {ex.Message}");
                }
            }
        }

        public static void LeerMiembros()
        {
            Console.Clear();
            Console.WriteLine("== Lista de Miembros ==");

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Miembros";
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    Console.WriteLine("ID | Nombre | Apellido | Fecha Nacimiento | Email | Teléfono");
                    while (reader.Read())
                    {
                        Console.WriteLine($"{reader["ID_Miembro"]} | {reader["Nombre"]} | {reader["Apellido"]} | {reader["FechaNacimiento"]} | {reader["Email"]} | {reader["Telefono"]}");
                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Error de SQL: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error general: {ex.Message}");
                }
            }
        }

        public static void ActualizarMiembro()
        {
            Console.Clear();
            Console.WriteLine("== Actualizar Miembro ==");

            Console.WriteLine("Ingrese el ID del miembro a actualizar:");
            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("ID inválido.");
                return;
            }

            Console.WriteLine("Ingrese el nuevo nombre del miembro:");
            string nombre = Console.ReadLine();

            Console.WriteLine("Ingrese el nuevo apellido del miembro:");
            string apellido = Console.ReadLine();

            Console.WriteLine("Ingrese el nuevo email:");
            string email = Console.ReadLine();

            Console.WriteLine("Ingrese el nuevo teléfono:");
            string telefono = Console.ReadLine();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Miembros SET Nombre = @Nombre, Apellido = @Apellido, Email = @Email, Telefono = @Telefono WHERE ID_Miembro = @ID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ID", id);
                command.Parameters.AddWithValue("@Nombre", nombre);
                command.Parameters.AddWithValue("@Apellido", apellido);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@Telefono", telefono);

                try
                {
                    connection.Open();
                    int result = command.ExecuteNonQuery();
                    if (result > 0)
                    {
                        Console.WriteLine("Miembro actualizado exitosamente.");
                    }
                    else
                    {
                        Console.WriteLine("No se encontró el miembro con el ID ingresado.");
                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Error de SQL: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error general: {ex.Message}");
                }
            }
        }

        public static void EliminarMiembro()
        {
            Console.Clear();
            Console.WriteLine("== Eliminar Miembro ==");

            Console.WriteLine("Ingrese el ID del miembro a eliminar:");
            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("ID inválido.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Miembros WHERE ID_Miembro = @ID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ID", id);

                try
                {
                    connection.Open();
                    int result = command.ExecuteNonQuery();
                    if (result > 0)
                    {
                        Console.WriteLine("Miembro eliminado exitosamente.");
                    }
                    else
                    {
                        Console.WriteLine("No se encontró el miembro con el ID ingresado.");
                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Error de SQL: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error general: {ex.Message}");
                }
            }
        }

    }
}
