﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace GYMEXTRAOR.CLASES
{
    internal class MembresiasCRUD
    {
        private static string connectionString = "Server=DESKTOP-P5L5BPG\\SQLEXPRESS01;Database=GYM;Integrated Security=True; TrustServerCertificate=True; ";

        public static void Menu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("==============================================");
                Console.WriteLine("          Gestión de Membresías");
                Console.WriteLine("==============================================");
                Console.WriteLine("Seleccione una opción:");
                Console.WriteLine("1. Agregar Membresía");
                Console.WriteLine("2. Listar Membresías");
                Console.WriteLine("3. Actualizar Membresía");
                Console.WriteLine("4. Eliminar Membresía");
                Console.WriteLine("0. Volver al Menú Principal");

                Console.Write("Opción: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        AgregarMembresia();
                        break;
                    case "2":
                        ListarMembresias();
                        break;
                    case "3":
                        ActualizarMembresia();
                        break;
                    case "4":
                        EliminarMembresia();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Opción no válida.");
                        break;
                }

                Console.WriteLine("\nPresiona cualquier tecla para continuar...");
                Console.ReadKey();
            }
        }

        private static void AgregarMembresia()
        {
            Console.WriteLine("\n== Agregar Membresía ==");

            // Solicitar tipo de membresía
            Console.WriteLine("Ingrese el tipo de membresía:");
            string tipoMembresia = Console.ReadLine();
            while (string.IsNullOrWhiteSpace(tipoMembresia))
            {
                Console.WriteLine("El tipo de membresía no puede estar vacío. Por favor, ingrese un tipo de membresía válido:");
                tipoMembresia = Console.ReadLine();
            }

            // Solicitar precio
            Console.WriteLine("Ingrese el precio de la membresía:");
            if (!decimal.TryParse(Console.ReadLine(), out decimal precio) || precio <= 0)
            {
                Console.WriteLine("El precio debe ser un número válido y mayor a 0. Operación cancelada.");
                return;
            }

            // Solicitar fecha de inicio
            Console.WriteLine("Ingrese la fecha de inicio de la membresía (YYYY-MM-DD):");
            string fechaInicioInput = Console.ReadLine();
            if (!DateTime.TryParse(fechaInicioInput, out DateTime fechaInicio))
            {
                Console.WriteLine("La fecha de inicio no es válida. Operación cancelada.");
                return;
            }

            // Solicitar fecha de fin
            Console.WriteLine("Ingrese la fecha de fin de la membresía (YYYY-MM-DD):");
            string fechaFinInput = Console.ReadLine();
            if (!DateTime.TryParse(fechaFinInput, out DateTime fechaFin) || fechaFin <= fechaInicio)
            {
                Console.WriteLine("La fecha de fin debe ser válida y posterior a la fecha de inicio. Operación cancelada.");
                return;
            }

            // Insertar en la base de datos
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Membresias (TipoMembresia, Precio, FechaInicio, FechaFin) VALUES (@TipoMembresia, @Precio, @FechaInicio, @FechaFin)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TipoMembresia", tipoMembresia);
                command.Parameters.AddWithValue("@Precio", precio);
                command.Parameters.AddWithValue("@FechaInicio", fechaInicio);
                command.Parameters.AddWithValue("@FechaFin", fechaFin);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        Console.WriteLine("\nMembresía agregada exitosamente.");
                    }
                    else
                    {
                        Console.WriteLine("\nError al agregar la membresía.");
                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Error de SQL: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error general: {ex.Message}");
                }
            }
        }

        private static void ListarMembresias()
        {
            Console.WriteLine("\nLista de Membresías:");
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Actualizamos la consulta SQL con los nombres correctos de las columnas
                string query = "SELECT ID_Membresia, TipoMembresia, Precio, FechaInicio, FechaFin FROM Membresias";
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            // Mostramos los datos con los nombres correctos de las columnas
                            Console.WriteLine($"ID: {reader["ID_Membresia"]}, Tipo: {reader["TipoMembresia"]}, Precio: {reader["Precio"]:C}, Inicio: {reader["FechaInicio"]:d}, Fin: {reader["FechaFin"]:d}");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No hay membresías registradas.");
                    }

                    reader.Close();
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Error de SQL: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error general: {ex.Message}");
                }
            }
        }

        private static void ActualizarMembresia()
        {
            Console.WriteLine("\nIngrese el ID de la membresía a actualizar:");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("Ingrese el nuevo tipo de membresía (o presione Enter para no cambiar):");
                string nuevoTipo = Console.ReadLine();

                Console.WriteLine("Ingrese el nuevo precio (o presione Enter para no cambiar):");
                string nuevaEntradaPrecio = Console.ReadLine();
                decimal? nuevoPrecio = null;
                if (!string.IsNullOrWhiteSpace(nuevaEntradaPrecio))
                {
                    // Validamos que el precio ingresado sea un número válido
                    if (!decimal.TryParse(nuevaEntradaPrecio, System.Globalization.NumberStyles.AllowDecimalPoint, System.Globalization.CultureInfo.InvariantCulture, out decimal precio))
                    {
                        Console.WriteLine("El precio ingresado no es válido. Operación cancelada.");
                        return;
                    }
                    nuevoPrecio = precio;
                }

                Console.WriteLine("Ingrese la nueva fecha de inicio (YYYY-MM-DD) (o presione Enter para no cambiar):");
                string nuevaFechaInicio = Console.ReadLine();
                DateTime? nuevaFechaInicioParsed = null;
                if (!string.IsNullOrWhiteSpace(nuevaFechaInicio))
                {
                    // Validamos que la fecha de inicio sea válida
                    if (!DateTime.TryParse(nuevaFechaInicio, out DateTime fechaInicio))
                    {
                        Console.WriteLine("La fecha de inicio ingresada no es válida. Operación cancelada.");
                        return;
                    }
                    nuevaFechaInicioParsed = fechaInicio;
                }

                Console.WriteLine("Ingrese la nueva fecha de fin (YYYY-MM-DD) (o presione Enter para no cambiar):");
                string nuevaFechaFin = Console.ReadLine();
                DateTime? nuevaFechaFinParsed = null;
                if (!string.IsNullOrWhiteSpace(nuevaFechaFin))
                {
                    // Validamos que la fecha de fin sea válida
                    if (!DateTime.TryParse(nuevaFechaFin, out DateTime fechaFin))
                    {
                        Console.WriteLine("La fecha de fin ingresada no es válida. Operación cancelada.");
                        return;
                    }

                    // Verificamos que la fecha de fin sea posterior a la fecha de inicio
                    if (nuevaFechaInicioParsed.HasValue && fechaFin <= nuevaFechaInicioParsed.Value)
                    {
                        Console.WriteLine("La fecha de fin debe ser posterior a la fecha de inicio. Operación cancelada.");
                        return;
                    }
                    nuevaFechaFinParsed = fechaFin;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Membresias SET " +
                                   "TipoMembresia = ISNULL(NULLIF(@TipoMembresia, ''), TipoMembresia), " +
                                   "Precio = ISNULL(@Precio, Precio), " +
                                   "FechaInicio = ISNULL(@FechaInicio, FechaInicio), " +
                                   "FechaFin = ISNULL(@FechaFin, FechaFin) " +
                                   "WHERE ID_Membresia = @ID";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID", id);
                    command.Parameters.AddWithValue("@TipoMembresia", string.IsNullOrWhiteSpace(nuevoTipo) ? (object)DBNull.Value : nuevoTipo);
                    command.Parameters.AddWithValue("@Precio", nuevoPrecio.HasValue ? (object)nuevoPrecio.Value : DBNull.Value);
                    command.Parameters.AddWithValue("@FechaInicio", nuevaFechaInicioParsed.HasValue ? (object)nuevaFechaInicioParsed.Value : DBNull.Value);
                    command.Parameters.AddWithValue("@FechaFin", nuevaFechaFinParsed.HasValue ? (object)nuevaFechaFinParsed.Value : DBNull.Value);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                            Console.WriteLine("\nMembresía actualizada exitosamente.");
                        else
                            Console.WriteLine("\nMembresía no encontrada.");
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"Error de SQL: {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error general: {ex.Message}");
                    }
                }
            }
            else
            {
                Console.WriteLine("\nID inválido.");
            }
        }
        private static void EliminarMembresia()
        {
            Console.WriteLine("\nIngrese el ID de la membresía a eliminar:");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Cambiamos 'Id' a 'ID_Membresia' para que coincida con la columna en la tabla
                    string query = "DELETE FROM Membresias WHERE ID_Membresia = @Id";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Id", id);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                            Console.WriteLine("\nMembresía eliminada exitosamente.");
                        else
                            Console.WriteLine("\nMembresía no encontrada.");
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"Error de SQL: {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error general: {ex.Message}");
                    }
                }
            }
            else
            {
                Console.WriteLine("\nID inválido.");
            }
        }



    }
}
