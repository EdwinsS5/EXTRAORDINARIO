﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace GYMEXTRAOR.CLASES
{
    internal class ReservasCRUD
    {
        private static string connectionString = "Server=DESKTOP-P5L5BPG\\SQLEXPRESS01;Database=GYM;Integrated Security=True;TrustServerCertificate=True;";

        public static void Menu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("==============================================");
                Console.WriteLine("          Gestión de Reservas");
                Console.WriteLine("==============================================");
                Console.WriteLine("Seleccione una opción:");
                Console.WriteLine("1. Agregar Reserva");
                Console.WriteLine("2. Listar Reservas");
                Console.WriteLine("3. Actualizar Reserva");
                Console.WriteLine("4. Eliminar Reserva");
                Console.WriteLine("0. Volver al Menú Principal");

                Console.Write("Opción: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        AgregarReserva();
                        break;
                    case "2":
                        ListarReservas();
                        break;
                    case "3":
                        ActualizarReserva();
                        break;
                    case "4":
                        EliminarReserva();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Opción no válida.");
                        break;
                }

                Console.WriteLine("\nPresiona cualquier tecla para continuar...");
                Console.ReadKey();
            }
        }

        private static void AgregarReserva()
        {
            Console.WriteLine("\nIngrese el ID del miembro:");
            if (int.TryParse(Console.ReadLine(), out int miembroId))
            {
                Console.WriteLine("Ingrese el ID de la clase:");
                if (int.TryParse(Console.ReadLine(), out int claseId))
                {
                    Console.WriteLine("Ingrese la fecha de la reserva (YYYY-MM-DD):");
                    string fechaReserva = Console.ReadLine();

                    // Validar el formato de la fecha
                    if (!DateTime.TryParse(fechaReserva, out DateTime fechaReservaParsed))
                    {
                        Console.WriteLine("\nLa fecha ingresada no es válida. Por favor, use el formato YYYY-MM-DD.");
                        return;
                    }

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        try
                        {
                            connection.Open();

                            // Verificar si el miembro existe
                            string miembroQuery = "SELECT COUNT(*) FROM Miembros WHERE ID_Miembro = @ID_Miembro";
                            using (SqlCommand miembroCommand = new SqlCommand(miembroQuery, connection))
                            {
                                miembroCommand.Parameters.AddWithValue("@ID_Miembro", miembroId);
                                int miembroCount = (int)miembroCommand.ExecuteScalar();
                                if (miembroCount == 0)
                                {
                                    Console.WriteLine("\nEl ID del miembro no existe.");
                                    return;
                                }
                            }

                            // Verificar si la clase existe
                            string claseQuery = "SELECT COUNT(*) FROM Clases WHERE ID_Clase = @ID_Clase";
                            using (SqlCommand claseCommand = new SqlCommand(claseQuery, connection))
                            {
                                claseCommand.Parameters.AddWithValue("@ID_Clase", claseId);
                                int claseCount = (int)claseCommand.ExecuteScalar();
                                if (claseCount == 0)
                                {
                                    Console.WriteLine("\nEl ID de la clase no existe.");
                                    return;
                                }
                            }

                            // Insertar la reserva
                            string reservaQuery = "INSERT INTO Reservas (ID_Miembro, ID_Clase, FechaReserva) VALUES (@ID_Miembro, @ID_Clase, @FechaReserva)";
                            using (SqlCommand reservaCommand = new SqlCommand(reservaQuery, connection))
                            {
                                reservaCommand.Parameters.AddWithValue("@ID_Miembro", miembroId);
                                reservaCommand.Parameters.AddWithValue("@ID_Clase", claseId);
                                reservaCommand.Parameters.AddWithValue("@FechaReserva", fechaReservaParsed);

                                int rowsAffected = reservaCommand.ExecuteNonQuery();
                                if (rowsAffected > 0)
                                    Console.WriteLine("\nReserva agregada exitosamente.");
                                else
                                    Console.WriteLine("\nError al agregar la reserva.");
                            }
                        }
                        catch (SqlException ex)
                        {
                            Console.WriteLine($"Error de SQL: {ex.Message}");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error general: {ex.Message}");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("\nID de la clase inválido.");
                }
            }
            else
            {
                Console.WriteLine("\nID del miembro inválido.");
            }
        }

        private static void ListarReservas()
        {
            Console.WriteLine("\nLista de Reservas:");
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Consulta SQL con los nombres de columnas corregidos
                string query = @"
            SELECT R.ID_Reserva, R.FechaReserva, 
                   M.Nombre AS MiembroNombre, 
                   C.NombreClase AS ClaseNombre
            FROM Reservas R
            INNER JOIN Miembros M ON R.ID_Miembro = M.ID_Miembro
            INNER JOIN Clases C ON R.ID_Clase = C.ID_Clase";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"ID Reserva: {reader["ID_Reserva"]}, Miembro: {reader["MiembroNombre"]}, Clase: {reader["ClaseNombre"]}, Fecha: {reader["FechaReserva"]}");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No hay reservas registradas.");
                    }

                    reader.Close();
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Error de SQL: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error general: {ex.Message}");
                }
            }
        }

        private static void ActualizarReserva()
        {
            Console.WriteLine("\nIngrese el ID de la reserva a actualizar:");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("Ingrese el nuevo ID del miembro:");
                if (int.TryParse(Console.ReadLine(), out int nuevoMiembroId))
                {
                    Console.WriteLine("Ingrese el nuevo ID de la clase:");
                    if (int.TryParse(Console.ReadLine(), out int nuevaClaseId))
                    {
                        Console.WriteLine("Ingrese la nueva fecha de la reserva (YYYY-MM-DD):");
                        string nuevaFechaReserva = Console.ReadLine();

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Usamos los nombres correctos de las columnas
                            string query = "UPDATE Reservas SET ID_Miembro = @ID_Miembro, ID_Clase = @ID_Clase, FechaReserva = @FechaReserva WHERE ID_Reserva = @ID_Reserva";

                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@ID_Reserva", id);
                            command.Parameters.AddWithValue("@ID_Miembro", nuevoMiembroId);
                            command.Parameters.AddWithValue("@ID_Clase", nuevaClaseId);
                            command.Parameters.AddWithValue("@FechaReserva", nuevaFechaReserva);

                            try
                            {
                                connection.Open();
                                int rowsAffected = command.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                    Console.WriteLine("\nReserva actualizada exitosamente.");
                                else
                                    Console.WriteLine("\nReserva no encontrada.");
                            }
                            catch (SqlException ex)
                            {
                                Console.WriteLine($"\nError de SQL: {ex.Message}");
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"\nError general: {ex.Message}");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nID de la clase inválido.");
                    }
                }
                else
                {
                    Console.WriteLine("\nID del miembro inválido.");
                }
            }
            else
            {
                Console.WriteLine("\nID inválido.");
            }
        }

        private static void EliminarReserva()
        {
            Console.WriteLine("\nIngrese el ID de la reserva a eliminar:");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Cambiamos "Id" a "ID_Reserva" en la consulta
                    string query = "DELETE FROM Reservas WHERE ID_Reserva = @ID_Reserva";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Reserva", id);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                            Console.WriteLine("\nReserva eliminada exitosamente.");
                        else
                            Console.WriteLine("\nReserva no encontrada.");
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"\nError de SQL: {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"\nError general: {ex.Message}");
                    }
                }
            }
            else
            {
                Console.WriteLine("\nID inválido.");
            }
        }
    }
}
